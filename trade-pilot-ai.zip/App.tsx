import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import ShipmentExperience from './components/ConsignmentBooker';
import MarketIntel from './components/MarketIntel';
import RiskAnalysis from './components/RiskAnalysis';
import BuyerFinder from './components/BuyerFinder';
import SupplierFinder from './components/SupplierFinder';
import OEMFinder from './components/OEMFinder';
import StudyGuide from './components/StudyGuide';
import ResourceHub from './components/ResourceHub';
import CampaignManager from './components/CampaignManager';
import GoogleMapExtractor from './components/GoogleMapExtractor';
import GoalPlanner from './components/GoalPlanner';
import ProfitCalculator from './components/ProfitCalculator';
import Settings from './components/Settings';
import Login from './components/Login';
import { Page, CompanyDetails, IconSet, Font } from './types';
import { translations, Currency } from './translations';
import { themes } from './themes';

const initialNavOrder: Page[] = [
    'dashboard',
    'study-guide',
    'market-intel',
    'resource-hub',
    'buyer-finder',
    'supplier-finder',
    'oem-finder',
    'map-extractor',
    'campaign-manager',
    'goal-planner',
    'profit-calculator',
    'shipment-experience',
    'risk',
    'settings',
];

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activePage, setActivePage] = useState<Page>('dashboard');
  const [companyProfile, setCompanyProfile] = useState<CompanyDetails | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [language, setLanguage] = useState('en');
  const [currency, setCurrency] = useState<Currency>({ code: 'INR', symbol: '₹' });
  const [theme, setTheme] = useState('Mint Breeze');
  const [font, setFont] = useState<Font>('Lato');
  const [navOrder, setNavOrder] = useState<Page[]>(initialNavOrder);
  const [iconSet, setIconSet] = useState<IconSet>('Duo-tone');

  const applyTheme = (themeName: string) => {
    const selectedTheme = themes.find(t => t.name === themeName);
    if (!selectedTheme) return;

    const root = document.documentElement;
    Object.entries(selectedTheme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value);
    });
  };
  
  const applyFont = (fontName: Font) => {
    document.documentElement.style.setProperty('--font-family', `"${fontName}", sans-serif`);
  };

  useEffect(() => {
    const loggedInStatus = localStorage.getItem('isLoggedIn');
    if (loggedInStatus === 'true') {
      setIsLoggedIn(true);
      const savedProfile = localStorage.getItem('companyProfile');
      if (savedProfile) {
        setCompanyProfile(JSON.parse(savedProfile));
      }
    }
    const sidebarStatus = localStorage.getItem('sidebarCollapsed');
    if (sidebarStatus === 'true') {
        setIsSidebarCollapsed(true);
    }
    const savedLang = localStorage.getItem('language');
    if (savedLang) setLanguage(savedLang);

    const savedCurrency = localStorage.getItem('currency');
    if (savedCurrency) setCurrency(JSON.parse(savedCurrency));
    
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme && themes.some(t => t.name === savedTheme)) {
        setTheme(savedTheme);
        applyTheme(savedTheme);
    } else {
        applyTheme('Mint Breeze'); // Apply default
    }
    
    const savedFont = localStorage.getItem('font') as Font;
    if (savedFont && ['Inter', 'Roboto', 'Lato', 'Poppins'].includes(savedFont)) {
      setFont(savedFont);
      applyFont(savedFont);
    } else {
      applyFont('Lato');
    }

    const savedNavOrder = localStorage.getItem('navOrder');
    if (savedNavOrder) {
        setNavOrder(JSON.parse(savedNavOrder));
    }
    
    const savedIconSet = localStorage.getItem('iconSet') as IconSet;
    if (savedIconSet && ['Line', 'Solid', 'Duo-tone'].includes(savedIconSet)) {
        setIconSet(savedIconSet);
    }

  }, []);

  const handleLogin = () => {
    localStorage.setItem('isLoggedIn', 'true');
    setIsLoggedIn(true);
    setActivePage('dashboard');
  };

  const handleLogout = () => {
    localStorage.clear();
    setIsLoggedIn(false);
    setCompanyProfile(null);
    setNavOrder(initialNavOrder); // Reset to default on logout
  };

  const handleProfileUpdate = (newProfile: CompanyDetails) => {
    localStorage.setItem('companyProfile', JSON.stringify(newProfile));
    setCompanyProfile(newProfile);
  };
  
  const toggleSidebar = () => {
      setIsSidebarCollapsed(prevState => {
          const newState = !prevState;
          localStorage.setItem('sidebarCollapsed', String(newState));
          return newState;
      });
  };
  
  const handleLanguageChange = (lang: string) => {
      setLanguage(lang);
      localStorage.setItem('language', lang);
  }

  const handleCurrencyChange = (curr: Currency) => {
      setCurrency(curr);
      localStorage.setItem('currency', JSON.stringify(curr));
  }
  
  const handleThemeChange = (themeName: string) => {
    setTheme(themeName);
    localStorage.setItem('theme', themeName);
    applyTheme(themeName);
  };

  const handleFontChange = (fontName: Font) => {
    setFont(fontName);
    localStorage.setItem('font', fontName);
    applyFont(fontName);
  }

  const handleIconSetChange = (style: IconSet) => {
    setIconSet(style);
    localStorage.setItem('iconSet', style);
  };
  
  const handleNavOrderChange = (newOrder: Page[]) => {
      setNavOrder(newOrder);
      localStorage.setItem('navOrder', JSON.stringify(newOrder));
  };

  const t = (key: keyof typeof translations.en) => {
    return translations[language as keyof typeof translations]?.[key] || translations.en[key];
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard setActivePage={setActivePage} t={t} />;
      case 'study-guide':
        return <StudyGuide t={t} setActivePage={setActivePage} />;
      case 'shipment-experience':
        return <ShipmentExperience t={t} currency={currency} setActivePage={setActivePage} />;
      case 'goal-planner':
        return <GoalPlanner t={t} currency={currency} setActivePage={setActivePage} />;
      case 'profit-calculator':
        return <ProfitCalculator t={t} currency={currency} setActivePage={setActivePage} />;
      case 'market-intel':
        return <MarketIntel t={t} setActivePage={setActivePage} />;
      case 'buyer-finder':
        return <BuyerFinder t={t} setActivePage={setActivePage} />;
      case 'supplier-finder':
        return <SupplierFinder t={t} setActivePage={setActivePage} />;
      case 'oem-finder':
        return <OEMFinder t={t} setActivePage={setActivePage} />;
      case 'map-extractor':
        return <GoogleMapExtractor t={t} setActivePage={setActivePage} />;
      case 'resource-hub':
        return <ResourceHub t={t} setActivePage={setActivePage} />;
      case 'campaign-manager':
        return <CampaignManager t={t} setActivePage={setActivePage} />;
      case 'risk':
        return <RiskAnalysis t={t} setActivePage={setActivePage} />;
      case 'settings':
        return <Settings 
                    language={language} onLanguageChange={handleLanguageChange} 
                    currency={currency} onCurrencyChange={handleCurrencyChange} 
                    theme={theme} onThemeChange={handleThemeChange}
                    font={font} onFontChange={handleFontChange}
                    iconSet={iconSet} onIconSetChange={handleIconSetChange}
                    applyTheme={applyTheme}
                    navOrder={navOrder} onNavOrderChange={handleNavOrderChange}
                    profile={companyProfile} onProfileUpdate={handleProfileUpdate}
                    t={t} 
                    setActivePage={setActivePage} />;
      default:
        return <Dashboard setActivePage={setActivePage} t={t} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-primary font-sans">
      <Sidebar 
        activePage={activePage} 
        setActivePage={setActivePage} 
        onLogout={handleLogout} 
        companyProfile={companyProfile}
        isCollapsed={isSidebarCollapsed}
        onToggle={toggleSidebar}
        navOrder={navOrder}
        iconSet={iconSet}
        t={t}
      />
      <main className={`flex-1 p-4 sm:p-6 lg:p-8 ${isSidebarCollapsed ? 'ml-16' : 'ml-16 sm:ml-64'} transition-all duration-300 bg-secondary`}>
        {renderContent()}
      </main>
    </div>
  );
};

export default App;