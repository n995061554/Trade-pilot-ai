
import React from 'react';

// --- PROPS ---

const lineIconProps: React.SVGProps<SVGSVGElement> = {
  className: "w-6 h-6",
  strokeWidth: "1.5",
  stroke: "currentColor",
  fill: "none",
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

const solidIconProps: React.SVGProps<SVGSVGElement> = {
  className: "w-6 h-6",
  fill: "currentColor",
  viewBox: "0 0 24 24",
};

const duoIconProps: React.SVGProps<SVGSVGElement> = {
  className: "w-6 h-6",
  viewBox: "0 0 24 24",
  fill: "currentColor",
};

// --- LINE ICONS (The Default Style) ---
const LineDashboardIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 4h6v8h-6z" /><path d="M4 16h6v4h-6z" /><path d="M14 12h6v8h-6z" /><path d="M14 4h6v4h-6z" /></svg> );
const LineStudyGuideIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 19a9 9 0 0 1 9 0a9 9 0 0 1 9 0" /><path d="M3 6a9 9 0 0 1 9 0a9 9 0 0 1 9 0" /><path d="M3 6l0 13" /><path d="M12 6l0 13" /><path d="M21 6l0 13" /></svg> );
const LineCalculatorIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 3m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z" /><path d="M8 7h8" /><path d="M8 11h8" /><path d="M8 15h8" /><path d="M11 18h2" /></svg> );
const LineMarketIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3a9 9 0 0 1 9 9a9 9 0 0 1 -9 9a9 9 0 0 1 -9 -9a9 9 0 0 1 9 -9z" /><path d="M12 12a2 2 0 1 0 2 2" /><path d="M12 12a2 2 0 1 0 -2 -2" /><path d="M12 12a2 2 0 1 0 -2 2" /><path d="M12 12a2 2 0 1 0 2 -2" /></svg> );
const LineBuyerFinderIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" /><path d="M21 21l-6 -6" /></svg> );
const LineSupplierFinderIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 21h18" /><path d="M5 21v-12l5 -4v16" /><path d="M19 21v-8l-6 -4" /><path d="M9 9l0 .01" /><path d="M9 12l0 .01" /><path d="M9 15l0 .01" /><path d="M15 12l0 .01" /><path d="M15 15l0 .01" /></svg> );
const LineOEMFinderIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-12l5 -4v16" /><path d="M15 21v-8l-5 -4" /><path d="M20 21v-12l-5 -4" /><path d="M9 21v-4a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v4" /></svg> );
const LineResourceHubIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h3l2 2h4a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2" /><path d="M9 17v-4" /><path d="M12 17v-1" /><path d="M15 17v-2" /></svg> );
const LineCampaignManagerIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16 10h4a2 2 0 0 1 0 4h-4l-4 7h-5l1 -7h-4a2 2 0 0 1 0 -4h4l4 -7h5l-1 7" /></svg> );
const LineRiskIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" /><path d="M12 9v4" /><path d="M12 16v.01" /></svg> );
const LineMapExtractorIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" /><path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z" /></svg> );
const LineConsignmentIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" /><path d="M18 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" /><path d="M5 18h-2v-11h3" /><path d="M18 18h2v-11h-3" /><path d="M3 3h18v2h-18z" /><path d="M6 5l1.5 6h9l1.5 -6" /><path d="M7.5 11l1 6" /><path d="M15.5 11l-1 6" /></svg> );
const LineGoalPlannerIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" /><path d="M12 12m-5 0a5 5 0 1 0 10 0a5 5 0 1 0 -10 0" /><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg> );
const LineLogoutIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" /><path d="M9 12h12l-3 -3" /><path d="M18 15l3 -3" /></svg> );
const LineChevronsLeftIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M11 7l-5 5l5 5" /><path d="M17 7l-5 5l5 5" /></svg> );
const LineChevronsRightIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M7 7l5 5l-5 5" /><path d="M13 7l5 5l-5 5" /></svg> );
const LineSettingsIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z" /><path d="M9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" /></svg> );

// --- SOLID ICONS ---
const SolidDashboardIcon = () => ( <svg {...solidIconProps}><path d="M4 4h6v8h-6z M4 16h6v4h-6z M14 12h6v8h-6z M14 4h6v4h-6z" /></svg> );
const SolidStudyGuideIcon = () => ( <svg {...solidIconProps}><path d="M12 5.25c-2.67 0-5.33.42-8 .9V19c2.67-.48 5.33-.9 8-.9s5.33.42 8 .9V6.15c-2.67-.48-5.33-.9-8-.9zM4 18.5V6.7c2.11-.37 4.43-.6 7-.6s4.89.23 7 .6v11.8c-2.11.37-4.43.6-7 .6s-4.89-.23-7-.6z" /></svg> );
const SolidCalculatorIcon = () => ( <svg {...solidIconProps}><path d="M6 2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm2 6v2h8V8H8zm0 4v2h8v-2H8zm0 4v2h2v-2H8z" /></svg> );
const SolidMarketIcon = () => ( <svg {...solidIconProps}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-2-8a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 4a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm-4 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/></svg> );
const SolidBuyerFinderIcon = () => ( <svg {...solidIconProps}><path d="M15.5 14h-.79l-.28-.27A6.5 6.5 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" /></svg> );
const SolidSupplierFinderIcon = () => ( <svg {...solidIconProps}><path d="M12 2L3 8v11h18V8L12 2zM7 18H5v-2h2v2zm0-4H5v-2h2v2zm0-4H5V8h2v2zm10 8h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V8h2v2zm-4 8h-2v-2h2v2zm-2-4h-2v-2h2v2z"/></svg> );
const SolidOEMFinderIcon = () => ( <svg {...solidIconProps}><path d="M12 2L3 8v11h6v-4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v4h6V8l-9-6zm-2 15H8v-2h2v2zm4 0h-2v-2h2v2z" /></svg> );
const SolidResourceHubIcon = () => ( <svg {...solidIconProps}><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z M9 17v-4h2v1h2v-1h2v4H9z" /></svg> );
const SolidCampaignManagerIcon = () => ( <svg {...solidIconProps}><path d="M14 6l-1-2H5v11h2v6l3-3h6l1-2V6h-5zM12 11H8V9h4v2zm4-2h-2V9h2v2z" /></svg> );
const SolidRiskIcon = () => ( <svg {...solidIconProps}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h2v2h-2zm0-8h2v6h-2z" /></svg> );
const SolidMapExtractorIcon = () => ( <svg {...solidIconProps}><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z" /></svg> );
const SolidConsignmentIcon = () => ( <svg {...solidIconProps}><path d="M20 8h-3V4H7v4H4c-1.1 0-2 .9-2 2v6h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-6c0-1.1-.9-2-2-2zM7.5 11l1 6H6.5l-1-6h2zm9 0l1 6h-2l-1-6h2zM6 6h12v3H6V6z" /></svg> );
const SolidGoalPlannerIcon = () => ( <svg {...solidIconProps}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" /></svg> );
const SolidLogoutIcon = () => ( <svg {...solidIconProps}><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z" /></svg> );
const SolidChevronsLeftIcon = () => ( <svg {...solidIconProps}><path d="M11.67 3.87L9.9 2.1 0 12l9.9 9.9 1.77-1.77L3.54 12z M18.67 3.87L16.9 2.1 7 12l9.9 9.9 1.77-1.77L10.54 12z"/></svg> );
const SolidChevronsRightIcon = () => ( <svg {...solidIconProps}><path d="M5.88 3.87L7.65 2.1 17.55 12l-9.9 9.9-1.77-1.77L14.01 12z M12.88 3.87L14.65 2.1 24.55 12l-9.9 9.9-1.77-1.77L21.01 12z"/></svg> );
const SolidSettingsIcon = () => ( <svg {...solidIconProps}><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" /></svg> );

// --- DUO-TONE ICONS ---
const DuoDashboardIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M4 12h6V4H4v8zm10-8v4h6V4h-6zM4 20h6v-4H4v4zm10 0h6v-8h-6v8z" /><path className="duotone-primary" d="M10 4v8H4V4h6zm6 0v4h6V4h-6zM10 16v4H4v-4h6zm6 4h6v-8h-6v8z"/></svg> );
const DuoStudyGuideIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M4 6.7c2.11-.37 4.43-.6 7-.6s4.89.23 7 .6V18c-2.11.37-4.43.6-7 .6s-4.89-.23-7-.6V6.7z" /><path className="duotone-primary" d="M12 5.25c-2.67 0-5.33.42-8 .9V19c2.67-.48 5.33-.9 8-.9s5.33.42 8 .9V6.15c-2.67-.48-5.33-.9-8-.9z M4 18.5V6.7c2.11-.37 4.43-.6 7-.6s4.89.23 7 .6v11.8c-2.11.37-4.43.6-7 .6s-4.89-.23-7-.6z" /></svg> );
const DuoCalculatorIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M8 8h8v2H8zm0 4h8v2H8zm0 4h2v2H8z" /><path className="duotone-primary" d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM8 18h2v-2H8v2zm0-4h8v-2H8v2zm0-4h8V8H8v2z" /></svg> );
const DuoMarketIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z M10 12c0-1.1.9-2 2-2s2 .9 2 2-.9 2-2 2-2-.9-2-2z" /><path className="duotone-primary" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z M10 12c0 1.1.9 2 2 2s2-.9 2-2-.9-2-2-2-2 .9-2 2z"/></svg> );
const DuoBuyerFinderIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zM9.5 14C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" /><path className="duotone-primary" d="M9.5 14c2.49 0 4.5-2.01 4.5-4.5S11.99 5 9.5 5 5 7.01 5 9.5 7.01 14 9.5 14z" /></svg> );
const DuoSupplierFinderIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M10 10h4v4h-4z" /><path className="duotone-primary" d="M12 2L3 8v11h18V8L12 2zM7 18H5v-2h2v2zm0-4H5v-2h2v2zm0-4H5V8h2v2zm10 8h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V8h2v2zm-4 8h-2v-2h2v2zm-2-4h-2v-2h2v2z" /></svg> );
const DuoOEMFinderIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M11 15h2v2h-2z" /><path className="duotone-primary" d="M12 2L3 8v11h6v-4c0-1.1.9-2 2-2h2c1.1 0 2 .9 2 2v4h6V8l-9-6zm-2 15H8v-2h2v2zm4 0h-2v-2h2v2z" /></svg> );
const DuoResourceHubIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M4 18h16V8h-8l-2-2H4v12z M9 17v-4h2v1h2v-1h2v4H9z" /><path className="duotone-primary" d="M20 6h-8l-2-2H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z M9 17v-4h2v1h2v-1h2v4H9z" /></svg> );
const DuoCampaignManagerIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M12 9H8v2h4z m4 0h-2v2h2z" /><path className="duotone-primary" d="M14 6l-1-2H5v11h2v6l3-3h6l1-2V6h-5zm-2 5H8V9h4v2zm4-2h-2V9h2v2z" /></svg> );
const DuoRiskIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M11 15h2v2h-2z m0-8h2v6h-2z" /><path className="duotone-primary" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-4h2v-6h-2v6zm0-8h2V7h-2v2z" /></svg> );
const DuoMapExtractorIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M12 9.5c1.38 0 2.5-1.12 2.5-2.5S13.38 4.5 12 4.5 9.5 5.62 9.5 7s1.12 2.5 2.5 2.5z" /><path className="duotone-primary" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z" /></svg> );
const DuoConsignmentIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M6 9h12V6H6v3z m1.5 8H6.5l-1-6h2l1 6z m9 0h-2l-1-6h2l1 6z" /><path className="duotone-primary" d="M20 8h-3V4H7v4H4c-1.1 0-2 .9-2 2v6h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-6c0-1.1-.9-2-2-2zM6 6h12v3H6V6zm1.5 11H6.5l-1-6h2l1 6zm9 0h-2l-1-6h2l1 6z" /></svg> );
const DuoGoalPlannerIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" /><path className="duotone-primary" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" /></svg> );
const DuoLogoutIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M18.17 13H8v-2h10.17l-2.58-2.58L17 7l5 5-5 5-1.41-1.41z M4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z" /><path className="duotone-primary" d="M4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5zm13 6l-5-5 1.41-1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5z" /></svg> );
const DuoChevronsLeftIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" d="M18.67 3.87L16.9 2.1 7 12l9.9 9.9 1.77-1.77L10.54 12z" /><path className="duotone-primary" d="M11.67 3.87L9.9 2.1 0 12l9.9 9.9 1.77-1.77L3.54 12z" /></svg> );
const DuoChevronsRightIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" d="M5.88 3.87L7.65 2.1 17.55 12l-9.9 9.9-1.77-1.77L14.01 12z" /><path className="duotone-primary" d="M12.88 3.87L14.65 2.1 24.55 12l-9.9 9.9-1.77-1.77L21.01 12z" /></svg> );
const DuoSettingsIcon = () => ( <svg {...duoIconProps}><path className="duotone-secondary" opacity=".3" d="M12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" /><path className="duotone-primary" d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61-.25-1.17-.59-1.69-.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" /></svg> );

{/* FIX: Define missing icon components */}
// --- Other Icons (Used across components but not in main nav) ---
const AiIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 21l2 -2l2 2" /><path d="M12 17v4" /><path d="M14 4l-2 2l-2 -2" /><path d="M12 11v-7" /><path d="M4 14l2 -2l-2 -2" /><path d="M11 12h-7" /><path d="M20 14l-2 -2l2 -2" /><path d="M13 12h7" /></svg> );
const DownloadIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" /><path d="M7 11l5 5l5 -5" /><path d="M12 4l0 12" /></svg> );
const GmailIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 7m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" /><path d="M3 7l9 6l9 -6" /></svg> );
const GlobeIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" /><path d="M3.6 9h16.8" /><path d="M3.6 15h16.8" /><path d="M11.5 3a17 17 0 0 0 0 18" /><path d="M12.5 3a17 17 0 0 1 0 18" /></svg> );
const CertificateIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 15m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" /><path d="M13 17.5v4.5l2 -1.5l2 1.5v-4.5" /><path d="M10 19h-5a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -1 1.73" /><path d="M6 9h4" /><path d="M6 12h3" /><path d="M6 15h2" /></svg> );
const HistoryIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 8l0 4l2 2" /><path d="M3.05 11a9 9 0 1 1 .5 4m-.5 5v-5h5" /></svg> );
const TagIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M11 3l9 9a1.5 1.5 0 0 1 0 2l-6 6a1.5 1.5 0 0 1 -2 0l-9 -9v-4a4 4 0 0 1 4 -4h4" /><circle cx="9" cy="9" r="1" /></svg> );
const GavelIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M11 21h-4a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v5" /><path d="M11 5l0 16" /><path d="M4 12h16" /><path d="M17 17m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" /><path d="M20 17l0 .01" /></svg> );
const BrainIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15.5 13a3.5 3.5 0 0 0 -3.5 3.5v1a3.5 3.5 0 0 0 7 0v-1.8" /><path d="M8.5 13a3.5 3.5 0 0 1 3.5 3.5v1a3.5 3.5 0 0 1 -7 0v-1.8" /><path d="M17.5 16a3.5 3.5 0 0 0 0 -7h-.5" /><path d="M19 9.3v-2.8a3.5 3.5 0 0 0 -7 0" /><path d="M6.5 16a3.5 3.5 0 0 1 0 -7h.5" /><path d="M5 9.3v-2.8a3.5 3.5 0 0 1 7 0v10" /></svg> );
const AlertTriangleIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 9v4" /><path d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z" /><path d="M12 16h.01" /></svg> );
const ShieldCheckIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 12l2 2l4 -4" /><path d="M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1 -8.5 15a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3" /></svg> );
const HSCodeIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 7v-1a2 2 0 0 1 2 -2h2" /><path d="M4 17v1a2 2 0 0 0 2 2h2" /><path d="M16 4h2a2 2 0 0 1 2 2v1" /><path d="M16 20h2a2 2 0 0 0 2 -2v-1" /><path d="M5 11h1v2h-1z" /><path d="M10 11v2" /><path d="M14 11h1v2h-1z" /><path d="M19 11v2" /></svg> );
const PaletteIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 21a9 9 0 0 1 0 -18c4.97 0 9 3.582 9 8c0 1.06 -.474 2.078 -1.318 2.828c-.844 .75 -1.989 1.172 -3.182 1.172h-2.5a2 2 0 0 0 -1 3.75a1.3 1.3 0 0 1 -1 2.25" /><path d="M8.5 10.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M12.5 7.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M16.5 10.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg> );
const MicrophoneIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 2m0 3a3 3 0 0 1 3 -3h0a3 3 0 0 1 3 3v5a3 3 0 0 1 -3 3h0a3 3 0 0 1 -3 -3z" /><path d="M5 10a7 7 0 0 0 14 0" /><path d="M8 21l8 0" /><path d="M12 17l0 4" /></svg> );
const MicrophoneOffIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 3l18 18" /><path d="M9 5a3 3 0 0 1 6 0v5a3 3 0 0 1 -.544 1.77" /><path d="M5 10a7 7 0 0 0 11.235 5.584" /><path d="M8 21l8 0" /><path d="M12 17l0 4" /></svg> );
const TextToSpeechIcon = () => ( <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 5m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" /><path d="M13 14v-1a2 2 0 0 0 -2 -2v-1" /><path d="M11 12v3" /><path d="M14 11v-1a2 2 0 1 1 4 0v3" /><path d="M17 12h-1.5" /></svg> );
const CompanyProfileIcon = () => ( <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M3 4m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v10a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z" /><path d="M9 10m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" /><path d="M15 8l2 0" /><path d="M15 12l2 0" /><path d="M7 16l10 0" /></svg> );


// Helper icons that aren't in the main nav list, but we'll provide variants for consistency
const { BackArrowIcon, LanguageIcon, CurrencyIcon, DragHandleIcon } = {
  BackArrowIcon: () => <svg {...lineIconProps} className="w-5 h-5"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l14 0" /><path d="M5 12l4 4" /><path d="M5 12l4 -4" /></svg>,
  LanguageIcon: () => <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 5h7" /><path d="M9 3v2c0 4.418 -2.239 8 -5 8" /><path d="M5 9c-.003 .668 -.006 1.335 -.009 2" /><path d="M12 20l4 -9l4 9" /><path d="M19.1 18h-6.2" /></svg>,
  CurrencyIcon: () => <svg {...lineIconProps}><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 12m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" /><path d="M5 8h14" /><path d="M5 16h14" /><path d="M8 5v14" /><path d="M16 5v14" /></svg>,
  DragHandleIcon: () => <svg {...lineIconProps} className="w-5 h-5 cursor-grab"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M9 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M9 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M15 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M15 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M15 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg>,
};


// --- ICON SETS EXPORT ---

const lineIcons = {
    DashboardIcon: LineDashboardIcon,
    StudyGuideIcon: LineStudyGuideIcon,
    CalculatorIcon: LineCalculatorIcon,
    MarketIcon: LineMarketIcon,
    BuyerFinderIcon: LineBuyerFinderIcon,
    SupplierFinderIcon: LineSupplierFinderIcon,
    OEMFinderIcon: LineOEMFinderIcon,
    ResourceHubIcon: LineResourceHubIcon,
    CampaignManagerIcon: LineCampaignManagerIcon,
    RiskIcon: LineRiskIcon,
    MapExtractorIcon: LineMapExtractorIcon,
    ConsignmentIcon: LineConsignmentIcon,
    GoalPlannerIcon: LineGoalPlannerIcon,
    LogoutIcon: LineLogoutIcon,
    ChevronsLeftIcon: LineChevronsLeftIcon,
    ChevronsRightIcon: LineChevronsRightIcon,
    SettingsIcon: LineSettingsIcon,
};

const solidIcons = {
    DashboardIcon: SolidDashboardIcon,
    StudyGuideIcon: SolidStudyGuideIcon,
    CalculatorIcon: SolidCalculatorIcon,
    MarketIcon: SolidMarketIcon,
    BuyerFinderIcon: SolidBuyerFinderIcon,
    SupplierFinderIcon: SolidSupplierFinderIcon,
    OEMFinderIcon: SolidOEMFinderIcon,
    ResourceHubIcon: SolidResourceHubIcon,
    CampaignManagerIcon: SolidCampaignManagerIcon,
    RiskIcon: SolidRiskIcon,
    MapExtractorIcon: SolidMapExtractorIcon,
    ConsignmentIcon: SolidConsignmentIcon,
    GoalPlannerIcon: SolidGoalPlannerIcon,
    LogoutIcon: SolidLogoutIcon,
    ChevronsLeftIcon: SolidChevronsLeftIcon,
    ChevronsRightIcon: SolidChevronsRightIcon,
    SettingsIcon: SolidSettingsIcon,
};

const duoToneIcons = {
    DashboardIcon: DuoDashboardIcon,
    StudyGuideIcon: DuoStudyGuideIcon,
    CalculatorIcon: DuoCalculatorIcon,
    MarketIcon: DuoMarketIcon,
    BuyerFinderIcon: DuoBuyerFinderIcon,
    SupplierFinderIcon: DuoSupplierFinderIcon,
    OEMFinderIcon: DuoOEMFinderIcon,
    ResourceHubIcon: DuoResourceHubIcon,
    CampaignManagerIcon: DuoCampaignManagerIcon,
    RiskIcon: DuoRiskIcon,
    MapExtractorIcon: DuoMapExtractorIcon,
    ConsignmentIcon: DuoConsignmentIcon,
    GoalPlannerIcon: DuoGoalPlannerIcon,
    LogoutIcon: DuoLogoutIcon,
    ChevronsLeftIcon: DuoChevronsLeftIcon,
    ChevronsRightIcon: DuoChevronsRightIcon,
    SettingsIcon: DuoSettingsIcon,
};

export const iconSets = {
    line: lineIcons,
    solid: solidIcons,
    'duo-tone': duoToneIcons,
};

// Export other icons that don't need different styles (or are handled inline)
export { BackArrowIcon, LanguageIcon, CurrencyIcon, DragHandleIcon, AiIcon, DownloadIcon, GmailIcon, GlobeIcon, CertificateIcon, HistoryIcon, TagIcon, GavelIcon, BrainIcon, AlertTriangleIcon, ShieldCheckIcon, HSCodeIcon, PaletteIcon, MicrophoneIcon, MicrophoneOffIcon, TextToSpeechIcon, CompanyProfileIcon };

// Note: Re-exporting all original line icons for direct use in components where style switching is not needed.
export { LineDashboardIcon as DashboardIcon, LineStudyGuideIcon as StudyGuideIcon, LineCalculatorIcon as CalculatorIcon, LineMarketIcon as MarketIcon, LineBuyerFinderIcon as BuyerFinderIcon, LineSupplierFinderIcon as SupplierFinderIcon, LineOEMFinderIcon as OEMFinderIcon, LineResourceHubIcon as ResourceHubIcon, LineCampaignManagerIcon as CampaignManagerIcon, LineRiskIcon as RiskIcon, LineMapExtractorIcon as MapExtractorIcon, LineConsignmentIcon as ConsignmentIcon, LineGoalPlannerIcon as GoalPlannerIcon, LineLogoutIcon as LogoutIcon, LineChevronsLeftIcon as ChevronsLeftIcon, LineChevronsRightIcon as ChevronsRightIcon, LineSettingsIcon as SettingsIcon };
