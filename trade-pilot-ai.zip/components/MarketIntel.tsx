
import React, { useState, useRef, useEffect } from 'react';
import { generateGroundedAiResponse, generateSpeech } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { translations } from '../translations';
import { MicrophoneIcon, MicrophoneOffIcon, TextToSpeechIcon, DownloadIcon, BrainIcon, BackArrowIcon } from './icons';
import { decode } from '../utils/audio';
import { GenerateContentResponse } from '@google/genai';
import { Page } from '../types';

interface MarketIntelProps {
  t: (key: keyof typeof translations.en) => string;
  setActivePage: (page: Page) => void;
}

const MarketIntel: React.FC<MarketIntelProps> = ({ t, setActivePage }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<GenerateContentResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    return () => {
      // Cleanup audio context on unmount
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, []);

  const presets = [
    "What are current global trade trends for agricultural products?",
    "Which countries have recently increased their import of Indian textiles?",
    "What is the latest news regarding shipping costs from India to Europe?",
    "Provide a market analysis for exporting organic spices to the USA, including recent consumer trends."
  ];

  const handleQuerySubmit = async (currentQuery: string) => {
    if (!currentQuery.trim()) return;
    setIsLoading(true);
    setResponse(null);
    try {
        const aiResponse = await generateGroundedAiResponse(currentQuery, isThinkingMode);
        setResponse(aiResponse);
    } catch(error) {
        console.error("Error fetching grounded response", error);
        // You could set an error state here to show in the UI
    }
    setIsLoading(false);
  };
  
  const handlePresetClick = (presetQuery: string) => {
    setQuery(presetQuery);
    handleQuerySubmit(presetQuery);
  };

  const startRecording = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorderRef.current = new MediaRecorder(stream);
        audioChunksRef.current = [];
        
        mediaRecorderRef.current.ondataavailable = event => {
            audioChunksRef.current.push(event.data);
        };

        mediaRecorderRef.current.onstop = async () => {
             // This is a simplified simulation. A real implementation would use a speech-to-text API.
             // For this app, we'll just simulate a transcription.
            alert("Audio recorded! In a real app, this would be transcribed. For now, please type your query.");
            stream.getTracks().forEach(track => track.stop()); // Stop the microphone access
        };

        mediaRecorderRef.current.start();
        setIsRecording(true);
    } catch (error) {
        console.error("Error accessing microphone:", error);
        alert("Could not access the microphone. Please check your browser permissions.");
    }
  };
  
   const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const handleMicClick = () => {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    };

    const playAudio = async (base64Audio: string) => {
        if (isSpeaking) return;
        setIsSpeaking(true);
        try {
            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const audioContext = audioContextRef.current;
            const audioData = decode(base64Audio);
            const rawData = new Int16Array(audioData.buffer);
            const frameCount = rawData.length;
            const audioBuffer = audioContext.createBuffer(1, frameCount, 24000);
            const channelData = audioBuffer.getChannelData(0);

            for (let i = 0; i < frameCount; i++) {
                channelData[i] = rawData[i] / 32768.0;
            }

            const source = audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContext.destination);
            source.onended = () => setIsSpeaking(false);
            source.start();
        } catch (error) {
            console.error("Error playing audio:", error);
            setIsSpeaking(false);
        }
    };
    
    const handleReadAloud = async () => {
      const textToRead = response?.text;
      if (!textToRead || isSpeaking) return;
      
      const audioData = await generateSpeech(textToRead);
      if (audioData) {
          playAudio(audioData);
      }
    };

    const handleDownload = () => {
      if (!response || !response.text) return;

      let reportContent = `Market Intelligence Report\n`;
      reportContent += `==========================\n\n`;
      reportContent += `Query: ${query}\n`;
      reportContent += `Thinking Mode: ${isThinkingMode ? 'Enabled' : 'Disabled'}\n\n`;
      reportContent += `--- AI Analysis ---\n`;
      reportContent += `${response.text}\n\n`;

      const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (sources && sources.length > 0) {
        reportContent += `--- Sources ---\n`;
        sources.forEach((chunk, index) => {
          reportContent += `${index + 1}. ${chunk.web.title}\n   ${chunk.web.uri}\n\n`;
        });
      }

      const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const fileName = `Market_Report_${query.substring(0, 25).replace(/\s/g, '_')}.txt`;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    };

  return (
    <div>
      <header className="mb-6">
        <button onClick={() => setActivePage('dashboard')} className="flex items-center gap-2 text-sm text-text-secondary hover:text-brand mb-4 transition-colors">
          <BackArrowIcon />
          <span>Back to Dashboard</span>
        </button>
        <h1 className="text-3xl font-bold text-text-primary">{t('marketIntelEngine')}</h1>
        <p className="text-md text-text-secondary">{t('marketIntelSubheading')}</p>
      </header>

      <div className="bg-primary p-4 rounded-lg shadow-lg mb-6">
        <div className="flex flex-wrap gap-2 mb-4">
            <h3 className="w-full text-sm font-semibold text-text-secondary mb-1">{t('tryPrompts')}</h3>
            {presets.map((p, i) => (
                <button 
                    key={i}
                    onClick={() => handlePresetClick(p)}
                    className="bg-accent text-text-primary px-3 py-1 rounded-full text-sm hover:bg-brand hover:text-primary transition"
                >
                    {p}
                </button>
            ))}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); handleQuerySubmit(query); }}>
          <div className="relative mb-3">
             <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('marketIntelPlaceholder')}
                className="w-full bg-secondary border-highlight rounded-md shadow-sm p-3 pr-12 text-text-primary focus:outline-none focus:ring-2 focus:ring-brand focus:border-brand"
                rows={3}
             />
             <button type="button" onClick={handleMicClick} className={`absolute top-3 right-3 p-1 rounded-full ${isRecording ? 'bg-red-500/50 text-red-200 animate-pulse' : 'bg-accent text-text-secondary hover:bg-brand'}`}>
                {isRecording ? <MicrophoneOffIcon /> : <MicrophoneIcon />}
             </button>
          </div>
           <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative group flex items-center gap-2">
                <label htmlFor="thinking-mode" className="flex items-center cursor-pointer">
                    <div className="relative">
                        <input type="checkbox" id="thinking-mode" className="sr-only" checked={isThinkingMode} onChange={() => setIsThinkingMode(!isThinkingMode)} />
                        <div className={`block w-12 h-6 rounded-full transition ${isThinkingMode ? 'bg-brand' : 'bg-accent'}`}></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isThinkingMode ? 'translate-x-6' : ''}`}></div>
                    </div>
                    <div className="ml-3 text-text-primary font-semibold flex items-center gap-2">
                         <BrainIcon />
                         {t('thinkingMode')}
                    </div>
                </label>
                 <div className="absolute bottom-full mb-2 w-max bg-highlight text-primary text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                    {t('thinkingModeTooltip')}
                </div>
            </div>
            <button 
                type="submit" 
                disabled={isLoading}
                className="w-full sm:w-auto flex-grow bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition disabled:bg-gray-500"
            >
                {isLoading ? <LoadingSpinner/> : t('askAI')}
            </button>
           </div>
        </form>
      </div>

      { (isLoading || response) && (
        <div className="bg-primary p-6 rounded-lg shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-text-primary">{t('aiAnalysis')}</h2>
            {response && !isLoading && (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleReadAloud}
                  disabled={isSpeaking}
                  className="flex items-center gap-2 bg-highlight text-text-primary text-sm font-semibold py-1 px-3 rounded-lg hover:bg-brand hover:text-primary transition disabled:bg-gray-500"
                >
                  {isSpeaking ? <LoadingSpinner/> : <TextToSpeechIcon />}
                  {t('readAloud')}
                </button>
                <button
                  onClick={handleDownload}
                  className="flex items-center gap-2 bg-highlight text-text-primary text-sm font-semibold py-1 px-3 rounded-lg hover:bg-brand hover:text-primary transition"
                >
                  <DownloadIcon />
                  {t('downloadReport')}
                </button>
              </div>
            )}
          </div>
          {isLoading && <LoadingSpinner />}
          {response?.text && <div className="prose prose-invert max-w-none text-text-secondary whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: response.text.replace(/\n/g, '<br />') }} />}
          
          {response?.candidates?.[0]?.groundingMetadata?.groundingChunks && response.candidates[0].groundingMetadata.groundingChunks.length > 0 && (
              <div className="mt-6 border-t border-accent pt-4">
                  <h3 className="text-lg font-semibold text-text-primary mb-2">Sources</h3>
                  <div className="flex flex-col gap-2">
                      {response.candidates[0].groundingMetadata.groundingChunks.map((chunk, index) => (
                          <a 
                            href={chunk.web.uri} 
                            key={index}
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm text-brand hover:underline bg-secondary p-2 rounded-md truncate"
                            title={chunk.web.title}
                          >
                              {index + 1}. {chunk.web.title}
                          </a>
                      ))}
                  </div>
              </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MarketIntel;
