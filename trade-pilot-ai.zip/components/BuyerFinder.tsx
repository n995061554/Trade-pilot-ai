
import React, { useState } from 'react';
// FIX: Import Page type
import { BuyerLead, CampaignContact, Page } from '../types';
import { generateCreativeAiResponse } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { translations } from '../translations';
// FIX: Import BackArrowIcon
import { GlobeIcon, CertificateIcon, HistoryIcon, BackArrowIcon } from './icons';

interface BuyerFinderProps {
    t: (key: keyof typeof translations.en) => string;
    // FIX: Add setActivePage to props
    setActivePage: (page: Page) => void;
}

const BuyerFinder: React.FC<BuyerFinderProps> = ({ t, setActivePage }) => {
    const [productCategory, setProductCategory] = useState('Spices');
    const [specificProduct, setSpecificProduct] = useState('Turmeric Powder');
    const [country, setCountry] = useState('UAE');
    const [buyerType, setBuyerType] = useState('Wholesaler');
    const [minVolume, setMinVolume] = useState('2 containers/month');
    
    const [leads, setLeads] = useState<BuyerLead[]>([]);
    const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isFindingMore, setIsFindingMore] = useState(false);
    const [isOnCooldown, setIsOnCooldown] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const getBuyers = async (isInitialSearch: boolean) => {
        if (isInitialSearch) {
            setIsLoading(true);
            setLeads([]);
            setSelectedLeads([]);
        } else {
            setIsFindingMore(true);
        }
        setError(null);

        const existingNames = isInitialSearch ? '' : `I have already found these companies: ${leads.map(l => l.companyName).join(', ')}. Please find 10 *new and different* companies that are not on this list.`;

        const prompt = `
        You are a real-time trade data analyst AI. Your data sources include official trade databases and verified B2B platforms.
        Find genuine international buyer leads based on the following criteria:
        - Product: "${specificProduct}" (category: "${productCategory}")
        - Target Country: "${country}"
        - Target Buyer Type: "${buyerType}"
        - Minimum Volume Requirement: "${minVolume}"
        
        ${existingNames}

        Your response MUST be a JSON array of objects. Each object represents one buyer lead.
        For each lead, you MUST provide all the following keys and data types:
        - "companyName": string (The official name of the importing company)
        - "contactPerson": string (A plausible name for a purchasing manager or director)
        - "email": string (A professional-looking, plausible email address, ideally with the company domain)
        - "phone": string (A plausible phone number for the target country)
        - "city": string (The primary city of operation)
        - "state": string (The state or province)
        - "country": string (The target country, which MUST be "${country}")
        - "estimatedVolume": string (A realistic yearly import volume based on available data)
        - "riskScore": number (An integer between 0 and 100, where a lower score is better/less risky)
        - "riskJustification": string (A brief, one-sentence summary for the assigned risk score)
        - "riskBreakdown": object (An object containing the basis for the risk score with three keys):
            - "website": string (Your assessment, e.g., 'Professional Website Verified', 'No Website Found', 'Basic Website')
            - "registration": string (Your assessment, e.g., 'Company Registration Verified', 'Registration Unclear', 'Data Not Found')
            - "tradeHistory": string (Your assessment, e.g., 'Established Trade History', 'New Importer', 'Limited Trade Data')

        Generate a minimum of 10 highly realistic leads based on your data sources. Do not include any text, explanations, or markdown formatting outside of the JSON array itself.
        `;

        try {
            const response = await generateCreativeAiResponse(prompt);
            const cleanedResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
            const parsedLeads: BuyerLead[] = JSON.parse(cleanedResponse);
             if (isInitialSearch) {
                setLeads(parsedLeads);
            } else {
                setLeads(prevLeads => [...prevLeads, ...parsedLeads]);
            }
        } catch (e) {
            console.error("Failed to get AI response:", e);
            const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred.';
            setError(`There was a problem finding buyers. ${errorMessage} Please try again later.`);
            if (isInitialSearch) {
                setLeads([]);
            }
        } finally {
             if (isInitialSearch) {
                setIsLoading(false);
            } else {
                setIsFindingMore(false);
                setIsOnCooldown(true);
                setTimeout(() => setIsOnCooldown(false), 3000);
            }
        }
    };
    
    const getRiskInfo = (score: number): { borderColor: string; bgColor: string; label: string; } => {
        if (score <= 30) return { borderColor: 'border-green-500', bgColor: 'bg-green-500', label: 'Low Risk' };
        if (score <= 70) return { borderColor: 'border-yellow-500', bgColor: 'bg-yellow-500', label: 'Medium Risk' };
        return { borderColor: 'border-red-500', bgColor: 'bg-red-500', label: 'High Risk' };
    };
    
    const handleSelectLead = (email: string) => {
        setSelectedLeads(prev =>
            prev.includes(email)
                ? prev.filter(e => e !== email)
                : [...prev, email]
        );
    };

    const handleAddToCampaign = () => {
        const leadsToAdd = leads.filter(lead => selectedLeads.includes(lead.email));
        const newContacts: CampaignContact[] = leadsToAdd.map(lead => ({
            id: Date.now() + Math.random(),
            companyName: lead.companyName,
            contactPerson: lead.contactPerson,
            email: lead.email,
            phone: lead.phone,
            country: lead.country,
            type: 'Buyer',
            product: specificProduct,
        }));

        const existingContactsJSON = localStorage.getItem('campaignContactList');
        const existingContacts: CampaignContact[] = existingContactsJSON ? JSON.parse(existingContactsJSON) : [];
        const uniqueNewContacts = newContacts.filter(
            newContact => !existingContacts.some(existing => existing.email === newContact.email)
        );
        
        if(uniqueNewContacts.length === 0){
             alert(`All ${selectedLeads.length} selected buyer(s) are already in your campaign list.`);
        } else {
            const updatedContacts = [...existingContacts, ...uniqueNewContacts];
            localStorage.setItem('campaignContactList', JSON.stringify(updatedContacts));
            alert(`${uniqueNewContacts.length} new buyer(s) added to your campaign list. Duplicates were ignored.`);
        }
        
        setSelectedLeads([]);
    };


    return (
        <div>
            <header className="mb-6">
                {/* FIX: Add back button for consistent UX */}
                <button onClick={() => setActivePage('dashboard')} className="flex items-center gap-2 text-sm text-text-secondary hover:text-brand mb-4 transition-colors">
                  <BackArrowIcon />
                  <span>Back to Dashboard</span>
                </button>
                <h1 className="text-3xl font-bold text-text-primary">Real-Time Buyer Search</h1>
                <p className="text-md text-text-secondary">Find and verify genuine international buyers using AI-powered data analysis.</p>
            </header>

            <div className="bg-primary p-6 rounded-lg shadow-lg mb-6">
                <form onSubmit={(e) => { e.preventDefault(); getBuyers(true); }} className="space-y-4">
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label htmlFor="specificProduct" className="block text-sm font-medium text-text-secondary">Specific Product</label>
                            <input id="specificProduct" value={specificProduct} onChange={(e) => setSpecificProduct(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Basmati Rice" required />
                        </div>
                        <div>
                            <label htmlFor="country" className="block text-sm font-medium text-text-secondary">Target Country</label>
                            <input id="country" value={country} onChange={(e) => setCountry(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., UAE" required />
                        </div>
                         <div>
                            <label htmlFor="productCategory" className="block text-sm font-medium text-text-secondary">Product Category</label>
                            <input id="productCategory" value={productCategory} onChange={(e) => setProductCategory(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Grains" required />
                        </div>
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="buyerType" className="block text-sm font-medium text-text-secondary">Target Buyer Type</label>
                            <select id="buyerType" value={buyerType} onChange={(e) => setBuyerType(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" required>
                                <option>Wholesaler</option>
                                <option>Distributor</option>
                                <option>Retail Chain</option>
                                <option>Importer</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="minVolume" className="block text-sm font-medium text-text-secondary">Minimum Volume Requirement</label>
                            <input id="minVolume" value={minVolume} onChange={(e) => setMinVolume(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., 2 containers/month" required />
                        </div>
                    </div>
                    <button type="submit" disabled={isLoading} className="w-full bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition disabled:bg-gray-500 h-10">
                        {isLoading ? <LoadingSpinner /> : 'Find Genuine Buyers'}
                    </button>
                </form>
            </div>

            {isLoading && (
                <div className="text-center py-10">
                    <div className="flex justify-center items-center"><LoadingSpinner /></div>
                    <p className="mt-4 text-text-secondary">Analyzing trade data...</p>
                </div>
            )}
            
            {error && <div className="bg-red-900/50 text-red-300 p-4 rounded-lg text-center">{error}</div>}

            {!isLoading && leads.length > 0 && (
                <>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        {leads.map((lead, index) => {
                            const risk = getRiskInfo(lead.riskScore);
                            const isSelected = selectedLeads.includes(lead.email);
                            return (
                                <div key={index} className={`bg-primary p-5 rounded-lg shadow-lg border-t-4 ${risk.borderColor} flex flex-col relative transition-all duration-200 ${isSelected ? 'ring-2 ring-brand' : ''}`}>
                                    <input
                                        type="checkbox"
                                        checked={isSelected}
                                        onChange={() => handleSelectLead(lead.email)}
                                        className="absolute top-4 right-4 h-5 w-5 rounded bg-accent border-highlight text-brand focus:ring-brand cursor-pointer"
                                        aria-label={`Select ${lead.companyName}`}
                                    />
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <h3 className="text-xl font-bold text-text-primary">{lead.companyName}</h3>
                                            <p className="text-sm text-text-secondary">{`${lead.city}, ${lead.country}`}</p>
                                        </div>
                                        <div className={`text-xs font-bold px-2 py-1 rounded-full ${risk.bgColor} text-primary whitespace-nowrap`}>
                                            {risk.label}
                                        </div>
                                    </div>
                                    
                                    <div className="flex-grow space-y-3 text-sm mb-4">
                                        <p><strong className="text-text-secondary font-semibold">Contact:</strong> {lead.contactPerson}</p>
                                        <p><strong className="text-text-secondary font-semibold">Email:</strong> <a href={`mailto:${lead.email}`} className="text-brand hover:underline">{lead.email}</a></p>
                                        <p><strong className="text-text-secondary font-semibold">Phone:</strong> {lead.phone}</p>
                                        <p><strong className="text-text-secondary font-semibold">Est. Volume:</strong> {lead.estimatedVolume}</p>
                                    </div>

                                    <div className="bg-secondary p-3 rounded-lg space-y-2 mb-4">
                                         <h4 className="text-sm font-bold text-text-primary mb-2">Genuineness Scorecard</h4>
                                         <div className="flex items-center gap-2 text-xs">
                                             <span className="text-highlight"><GlobeIcon /></span>
                                             <span className="font-semibold text-text-secondary w-24">Website:</span>
                                             <span className="text-text-primary">{lead.riskBreakdown?.website}</span>
                                         </div>
                                         <div className="flex items-center gap-2 text-xs">
                                             <span className="text-highlight"><CertificateIcon /></span>
                                             <span className="font-semibold text-text-secondary w-24">Registration:</span>
                                             <span className="text-text-primary">{lead.riskBreakdown?.registration}</span>
                                         </div>
                                         <div className="flex items-center gap-2 text-xs">
                                             <span className="text-highlight"><HistoryIcon /></span>
                                             <span className="font-semibold text-text-secondary w-24">Trade History:</span>
                                             <span className="text-text-primary">{lead.riskBreakdown?.tradeHistory}</span>
                                         </div>
                                    </div>
                                    
                                    <div className="p-3 bg-accent/50 rounded-md text-sm">
                                        <p><strong className="text-text-secondary font-semibold">Risk Summary:</strong> {lead.riskJustification}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <div className="mt-8 flex justify-center">
                        <button onClick={() => getBuyers(false)} disabled={isFindingMore || isOnCooldown} className="w-full md:w-1/2 bg-highlight text-text-primary font-bold py-2 px-4 rounded-lg hover:bg-brand hover:text-primary transition disabled:bg-gray-500 disabled:cursor-wait h-10">
                            {isFindingMore ? <LoadingSpinner /> : isOnCooldown ? 'Please wait...' : 'Find More Buyers'}
                        </button>
                    </div>
                </>
            )}
            
             {!isLoading && !error && leads.length === 0 && (
                <div className="text-center py-10 text-text-secondary bg-primary rounded-lg">
                    <h3 className="text-lg font-semibold text-text-primary">Ready to Find Buyers?</h3>
                    <p>Enter your product and location details to begin.</p>
                </div>
            )}
            
            {selectedLeads.length > 0 && (
                <div className="sticky bottom-4 w-full flex justify-center items-center z-20">
                    <div className="bg-primary p-3 rounded-lg shadow-2xl flex items-center gap-4 border border-brand animate-fadeInUp">
                         <p className="text-text-primary font-semibold">{selectedLeads.length} buyer(s) selected.</p>
                         <button
                            onClick={handleAddToCampaign}
                            className="bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition"
                        >
                            Add to Campaign List
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BuyerFinder;