
import React, { useState } from 'react';
// FIX: Import Page type
import { OEMLead, CampaignContact, Page } from '../types';
import { generateCreativeAiResponse } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { translations } from '../translations';
// FIX: Import BackArrowIcon
import { BackArrowIcon } from './icons';

interface OEMFinderProps {
    t: (key: keyof typeof translations.en) => string;
    // FIX: Add setActivePage to props
    setActivePage: (page: Page) => void;
}

const OEMFinder: React.FC<OEMFinderProps> = ({ t, setActivePage }) => {
    const [productCategory, setProductCategory] = useState('Apparel');
    const [specificProduct, setSpecificProduct] = useState('Denim Jeans');
    const [city, setCity] = useState('Ahmedabad');
    const [state, setState] = useState('Gujarat');
    const [country, setCountry] = useState('India');
    
    const [leads, setLeads] = useState<OEMLead[]>([]);
    const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isFindingMore, setIsFindingMore] = useState(false);
    const [isOnCooldown, setIsOnCooldown] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const getOEMs = async (isInitialSearch: boolean) => {
        if (isInitialSearch) {
            setIsLoading(true);
            setLeads([]);
            setSelectedLeads([]);
        } else {
            setIsFindingMore(true);
        }
        setError(null);

        const existingNames = isInitialSearch ? '' : `I have already found the following manufacturers: ${leads.map(l => l.manufacturerName).join(', ')}. Please find 10 *new and different* manufacturers that are not on this list.`;

        const prompt = `
        You are a B2B sourcing expert AI. Find potential Original Equipment Manufacturers (OEMs) for "${specificProduct}" within the "${productCategory}" category, located near "${city}, ${state}, ${country}". These manufacturers should be suitable for private labeling.
        ${existingNames}
        Your response MUST be a JSON array of objects.
        Each object represents a single manufacturer and MUST have the following keys and data types:
        - "manufacturerName": string (The name of the OEM company)
        - "city": string (The city where they are located)
        - "state": string (The state where they are located)
        - "country": string (The country, which should be "${country}")
        - "specialization": string (Their specific manufacturing expertise, e.g., "High-volume denim jeans production")
        - "minOrderQuantity": string (A realistic MOQ, e.g., "500 pieces per style")
        - "certifications": array of strings (List of plausible certifications like "ISO 9001", "GOTS", "SA8000")
        - "contactPerson": string (A plausible name for a business development manager)
        - "email": string (A professional-looking, plausible email address)
        - "phone": string (A plausible Indian phone number)
        - "privateLabelExperience": string (A brief summary of their experience with private labeling, e.g., "Experienced in working with international brands for private label manufacturing.")

        Generate a minimum of 10 realistic-looking leads. Do not include any text, explanations, or markdown formatting outside of the JSON array itself.
        `;

        try {
            const response = await generateCreativeAiResponse(prompt);
            const cleanedResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
            const parsedLeads: OEMLead[] = JSON.parse(cleanedResponse);
            if (isInitialSearch) {
                setLeads(parsedLeads);
            } else {
                setLeads(prevLeads => [...prevLeads, ...parsedLeads]);
            }
        } catch (e) {
            console.error("Failed to get AI response:", e);
            const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred.';
            setError(`There was a problem finding manufacturers. ${errorMessage} Please try again later.`);
            if (isInitialSearch) {
                setLeads([]);
            }
        } finally {
             if (isInitialSearch) {
                setIsLoading(false);
            } else {
                setIsFindingMore(false);
                setIsOnCooldown(true);
                setTimeout(() => setIsOnCooldown(false), 3000);
            }
        }
    };
    
    const handleSelectLead = (email: string) => {
        setSelectedLeads(prev =>
            prev.includes(email)
                ? prev.filter(e => e !== email)
                : [...prev, email]
        );
    };

    const handleAddToCampaign = () => {
        const leadsToAdd = leads.filter(lead => selectedLeads.includes(lead.email));
        const newContacts: CampaignContact[] = leadsToAdd.map(lead => ({
            id: Date.now() + Math.random(),
            companyName: lead.manufacturerName,
            contactPerson: lead.contactPerson,
            email: lead.email,
            phone: lead.phone,
            country: lead.country,
            type: 'OEM',
            product: specificProduct,
        }));

        const existingContactsJSON = localStorage.getItem('campaignContactList');
        const existingContacts: CampaignContact[] = existingContactsJSON ? JSON.parse(existingContactsJSON) : [];
        const uniqueNewContacts = newContacts.filter(
            newContact => !existingContacts.some(existing => existing.email === newContact.email)
        );
        
        if(uniqueNewContacts.length === 0){
             alert(`All ${selectedLeads.length} selected manufacturer(s) are already in your campaign list.`);
        } else {
            const updatedContacts = [...existingContacts, ...uniqueNewContacts];
            localStorage.setItem('campaignContactList', JSON.stringify(updatedContacts));
            alert(`${uniqueNewContacts.length} new manufacturer(s) added to your campaign list. Duplicates were ignored.`);
        }
        
        setSelectedLeads([]);
    };

    return (
        <div>
            <header className="mb-6">
                {/* FIX: Add back button for consistent UX */}
                <button onClick={() => setActivePage('dashboard')} className="flex items-center gap-2 text-sm text-text-secondary hover:text-brand mb-4 transition-colors">
                  <BackArrowIcon />
                  <span>Back to Dashboard</span>
                </button>
                <h1 className="text-3xl font-bold text-text-primary">AI-Powered OEM Finder</h1>
                <p className="text-md text-text-secondary">Discover manufacturers for building your own private label brand.</p>
            </header>

            <div className="bg-primary p-6 rounded-lg shadow-lg mb-6">
                <form onSubmit={(e) => { e.preventDefault(); getOEMs(true); }} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="productCategory" className="block text-sm font-medium text-text-secondary">Product Category</label>
                            <input id="productCategory" value={productCategory} onChange={(e) => setProductCategory(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Home Decor" required />
                        </div>
                        <div>
                            <label htmlFor="specificProduct" className="block text-sm font-medium text-text-secondary">Specific Product</label>
                            <input id="specificProduct" value={specificProduct} onChange={(e) => setSpecificProduct(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Wooden Photo Frames" required />
                        </div>
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label htmlFor="city" className="block text-sm font-medium text-text-secondary">City</label>
                            <input id="city" value={city} onChange={(e) => setCity(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Moradabad" required />
                        </div>
                        <div>
                            <label htmlFor="state" className="block text-sm font-medium text-text-secondary">State</label>
                            <input id="state" value={state} onChange={(e) => setState(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., Uttar Pradesh" required />
                        </div>
                         <div>
                            <label htmlFor="country" className="block text-sm font-medium text-text-secondary">Country</label>
                            <input id="country" value={country} onChange={(e) => setCountry(e.target.value)} className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="e.g., India" required />
                        </div>
                    </div>
                    <button type="submit" disabled={isLoading} className="w-full bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition disabled:bg-gray-500 h-10">
                        {isLoading ? <LoadingSpinner /> : 'Find OEMs'}
                    </button>
                </form>
            </div>

            {isLoading && (
                <div className="text-center py-10">
                    <div className="flex justify-center items-center"><LoadingSpinner /></div>
                    <p className="mt-4 text-text-secondary">Searching for manufacturers...</p>
                </div>
            )}
            
            {error && <div className="bg-red-900/50 text-red-300 p-4 rounded-lg text-center">{error}</div>}

            {!isLoading && leads.length > 0 && (
                <>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {leads.map((lead, index) => {
                            const isSelected = selectedLeads.includes(lead.email);
                            return (
                            <div key={index} className={`bg-primary p-5 rounded-lg shadow-lg border-t-4 border-brand flex flex-col relative transition-all duration-200 ${isSelected ? 'ring-2 ring-brand' : ''}`}>
                                <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={() => handleSelectLead(lead.email)}
                                    className="absolute top-4 right-4 h-5 w-5 rounded bg-accent border-highlight text-brand focus:ring-brand cursor-pointer"
                                    aria-label={`Select ${lead.manufacturerName}`}
                                />
                                <div className="mb-3">
                                    <h3 className="text-xl font-bold text-text-primary">{lead.manufacturerName}</h3>
                                    <p className="text-sm text-text-secondary">{`${lead.city}, ${lead.state}`}</p>
                                </div>
                                <div className="space-y-3 text-sm flex-grow mb-4">
                                    <p><strong className="text-text-secondary font-semibold">Specialization:</strong> {lead.specialization}</p>
                                    <p><strong className="text-text-secondary font-semibold">Min. Order (MOQ):</strong> <span className="font-mono text-brand bg-secondary px-2 py-1 rounded">{lead.minOrderQuantity}</span></p>
                                    <div>
                                        <strong className="text-text-secondary font-semibold">Certifications:</strong>
                                        <div className="flex flex-wrap gap-2 mt-1">
                                            {lead.certifications.map(cert => <span key={cert} className="text-xs bg-highlight text-text-primary px-2 py-1 rounded-full">{cert}</span>)}
                                        </div>
                                    </div>
                                    <p><strong className="text-text-secondary font-semibold">Contact:</strong> {lead.contactPerson}</p>
                                    <p><strong className="text-text-secondary font-semibold">Email:</strong> <a href={`mailto:${lead.email}`} className="text-brand hover:underline">{lead.email}</a></p>
                                    <p><strong className="text-text-secondary font-semibold">Phone:</strong> {lead.phone}</p>
                                </div>
                                <div className="p-3 bg-accent/50 rounded-md text-sm">
                                    <p><strong className="text-text-secondary font-semibold">Private Label Experience:</strong> {lead.privateLabelExperience}</p>
                                </div>
                            </div>
                        )})}
                    </div>
                    <div className="mt-8 flex justify-center">
                        <button onClick={() => getOEMs(false)} disabled={isFindingMore || isOnCooldown} className="w-full md:w-1/2 bg-highlight text-text-primary font-bold py-2 px-4 rounded-lg hover:bg-brand hover:text-primary transition disabled:bg-gray-500 disabled:cursor-wait h-10">
                            {isFindingMore ? <LoadingSpinner /> : isOnCooldown ? 'Please wait...' : 'Find More Manufacturers'}
                        </button>
                    </div>
                </>
            )}
            
             {!isLoading && !error && leads.length === 0 && (
                <div className="text-center py-10 text-text-secondary bg-primary rounded-lg">
                    <h3 className="text-lg font-semibold text-text-primary">Ready to Find an OEM Partner?</h3>
                    <p>Enter your product and location details to begin.</p>
                </div>
            )}

            {selectedLeads.length > 0 && (
                <div className="sticky bottom-4 w-full flex justify-center items-center z-20">
                    <div className="bg-primary p-3 rounded-lg shadow-2xl flex items-center gap-4 border border-brand animate-fadeInUp">
                         <p className="text-text-primary font-semibold">{selectedLeads.length} manufacturer(s) selected.</p>
                         <button
                            onClick={handleAddToCampaign}
                            className="bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition"
                        >
                            Add to Campaign List
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OEMFinder;