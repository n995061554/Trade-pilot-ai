import React from 'react';
import { Page, CompanyDetails, IconSet } from '../types';
import { translations } from '../translations';
import { iconSets } from './icons';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
  onLogout: () => void;
  companyProfile: CompanyDetails | null;
  isCollapsed: boolean;
  onToggle: () => void;
  navOrder: Page[];
  iconSet: IconSet;
  t: (key: keyof typeof translations.en) => string;
}

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, onLogout, companyProfile, isCollapsed, onToggle, navOrder, iconSet, t }) => {
  const selectedIcons = iconSets[iconSet.toLowerCase() as keyof typeof iconSets] || iconSets.line;

  const allNavItems: Record<Page, { icon: React.ReactElement; label: string }> = {
    'dashboard': { icon: React.createElement(selectedIcons.DashboardIcon), label: t('dashboard') },
    'study-guide': { icon: React.createElement(selectedIcons.StudyGuideIcon), label: t('studyGuide') },
    'market-intel': { icon: React.createElement(selectedIcons.MarketIcon), label: t('marketIntel') },
    'resource-hub': { icon: React.createElement(selectedIcons.ResourceHubIcon), label: t('resourceHub') },
    'buyer-finder': { icon: React.createElement(selectedIcons.BuyerFinderIcon), label: t('buyerFinder') },
    'supplier-finder': { icon: React.createElement(selectedIcons.SupplierFinderIcon), label: t('supplierFinder') },
    'oem-finder': { icon: React.createElement(selectedIcons.OEMFinderIcon), label: t('oemFinder') },
    'map-extractor': { icon: React.createElement(selectedIcons.MapExtractorIcon), label: t('mapExtractor') },
    'campaign-manager': { icon: React.createElement(selectedIcons.CampaignManagerIcon), label: t('campaignManager') },
    'goal-planner': { icon: React.createElement(selectedIcons.GoalPlannerIcon), label: t('goalPlanner') },
    'profit-calculator': { icon: React.createElement(selectedIcons.CalculatorIcon), label: t('profitCalculator') },
    'shipment-experience': { icon: React.createElement(selectedIcons.ConsignmentIcon), label: t('shipmentExperience') },
    'risk': { icon: React.createElement(selectedIcons.RiskIcon), label: t('riskAnalysis') },
    'settings': { icon: React.createElement(selectedIcons.SettingsIcon), label: t('settings') },
  };

  const orderedNavItems = navOrder.map(pageId => ({
      id: pageId,
      ...allNavItems[pageId]
  })).filter(item => item.label); // Filter out any invalid items

  const companyInitial = companyProfile?.companyName ? companyProfile.companyName.charAt(0).toUpperCase() : 'T';

  return (
    <aside className={`fixed top-0 left-0 h-full bg-secondary shadow-lg z-10 transition-all duration-300 flex flex-col ${isCollapsed ? 'w-16' : 'w-16 sm:w-64'}`}>
      <div className={`flex items-center h-20 border-b border-accent flex-shrink-0 ${isCollapsed ? 'justify-center' : 'justify-center sm:justify-start sm:pl-6'}`}>
        {companyProfile?.logo ? (
          <img src={companyProfile.logo} alt="Company Logo" className="w-9 h-9 rounded-full object-cover flex-shrink-0" />
        ) : (
          <div className="w-8 h-8 bg-brand rounded-full flex items-center justify-center text-primary font-bold flex-shrink-0">{companyInitial}</div>
        )}
        {!isCollapsed && <span className="hidden sm:inline ml-3 text-xl font-bold text-text-primary truncate">{companyProfile?.companyName || 'Trade Pilot AI'}</span>}
      </div>
      <nav className="mt-4 flex-grow overflow-y-auto">
        <ul>
          {orderedNavItems.map((item) => (
            <li key={item.id} className={`${isCollapsed ? 'px-3' : 'px-3 sm:px-6'} py-1`}>
              <button
                onClick={() => setActivePage(item.id)}
                className={`flex items-center w-full p-3 rounded-lg transition-colors duration-200 ${
                  activePage === item.id
                    ? 'bg-brand text-primary'
                    : 'text-text-secondary hover:bg-accent hover:text-text-primary'
                }`}
              >
                {item.icon}
                {!isCollapsed && <span className="hidden sm:inline ml-4 font-semibold">{item.label}</span>}
              </button>
            </li>
          ))}
        </ul>
      </nav>
       <div className={`mt-auto border-t border-accent flex-shrink-0 ${isCollapsed ? 'p-3' : 'p-3 sm:p-6'}`}>
         <button
            onClick={onToggle}
            className="flex items-center w-full p-3 rounded-lg transition-colors duration-200 text-text-secondary hover:bg-accent hover:text-text-primary mb-2"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
         >
            {React.createElement(isCollapsed ? selectedIcons.ChevronsRightIcon : selectedIcons.ChevronsLeftIcon)}
            {!isCollapsed && <span className="hidden sm:inline ml-4 font-semibold">{t('collapse')}</span>}
         </button>
         <button
          onClick={onLogout}
          className="flex items-center w-full p-3 rounded-lg transition-colors duration-200 text-text-secondary hover:bg-red-500/20 hover:text-red-300"
        >
          {React.createElement(selectedIcons.LogoutIcon)}
          {!isCollapsed && <span className="hidden sm:inline ml-4 font-semibold">{t('logout')}</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;