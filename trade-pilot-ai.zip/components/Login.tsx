import React, { useState } from 'react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [view, setView] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const switchView = (newView: 'login' | 'signup' | 'forgot') => {
    setError('');
    setEmail('');
    setPassword('');
    setName('');
    setConfirmPassword('');
    setView(newView);
  };

  const isValidEmail = (email: string) => {
    // A standard regex for email validation
    const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return emailRegex.test(String(email).toLowerCase());
  };


  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }
    if (!isValidEmail(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    onLogin(); 
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password || !confirmPassword) {
        setError('Please fill in all fields.');
        return;
    }
    if (!isValidEmail(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setError('');
    alert('Account created successfully! (Simulation)\nPlease sign in with your new credentials.');
    switchView('login');
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email address.');
      return;
    }
    if (!isValidEmail(email)) {
        setError('Please enter a valid email address.');
        return;
    }
    setError('');
    alert(`If an account exists for ${email}, a password reset link has been sent. (Simulation)`);
    switchView('login');
  };
  
  const renderLoginView = () => (
    <>
      <div className="text-center">
        <div className="flex items-center justify-center mx-auto w-12 h-12 bg-brand rounded-full text-primary font-bold text-2xl">T</div>
        <h2 className="mt-6 text-3xl font-extrabold text-text-primary">
          Sign in to Trade Pilot AI
        </h2>
        <p className="mt-2 text-sm text-text-secondary">
          Enter your credentials to access your dashboard.
        </p>
      </div>
      <form className="mt-8 space-y-6" onSubmit={handleLogin}>
        <div className="rounded-md shadow-sm -space-y-px">
          <div>
            <label htmlFor="email-address-login" className="sr-only">Email address</label>
            <input
              id="email-address-login"
              name="email"
              type="email"
              autoComplete="email"
              required
              className="appearance-none rounded-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-t-md focus:outline-none focus:ring-brand focus:border-brand focus:z-10 sm:text-sm"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="password-login" className="sr-only">Password</label>
            <input
              id="password-login"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              className="appearance-none rounded-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-b-md focus:outline-none focus:ring-brand focus:border-brand focus:z-10 sm:text-sm"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input id="remember-me" name="remember-me" type="checkbox" className="h-4 w-4 text-brand bg-primary border-accent rounded focus:ring-brand" />
            <label htmlFor="remember-me" className="ml-2 block text-sm text-text-secondary">
              Remember me
            </label>
          </div>
          <div className="text-sm">
            <button type="button" onClick={() => switchView('forgot')} className="font-medium text-brand hover:text-opacity-80">
              Forgot your password?
            </button>
          </div>
        </div>
        <div>
          <button
            type="submit"
            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-primary bg-brand hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand focus:ring-offset-primary"
          >
            Sign in
          </button>
        </div>
      </form>
      <div className="text-center">
        <p className="text-sm text-text-secondary">
          Don't have an account?{' '}
          <button type="button" onClick={() => switchView('signup')} className="font-medium text-brand hover:text-opacity-80">
            Create one now
          </button>
        </p>
        <p className="text-xs text-text-secondary mt-4">
          This is a simulated login for demonstration purposes.
        </p>
      </div>
    </>
  );

  const renderSignUpView = () => (
    <>
      <div className="text-center">
        <h2 className="mt-6 text-3xl font-extrabold text-text-primary">
          Create an Account
        </h2>
        <p className="mt-2 text-sm text-text-secondary">
          Join the platform to start your export journey.
        </p>
      </div>
      <form className="mt-8 space-y-6" onSubmit={handleSignUp}>
        <div className="rounded-md shadow-sm space-y-4">
           <input name="name" type="text" required className="appearance-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-md focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="Full Name" value={name} onChange={(e) => setName(e.target.value)} />
           <input name="email" type="email" autoComplete="email" required className="appearance-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-md focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
           <input name="password" type="password" required className="appearance-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-md focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
           <input name="confirmPassword" type="password" required className="appearance-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-md focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
        </div>
        <div>
          <button type="submit" className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-primary bg-brand hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand focus:ring-offset-primary">
            Sign Up
          </button>
        </div>
      </form>
      <div className="text-center">
        <p className="text-sm text-text-secondary">
          Already have an account?{' '}
          <button type="button" onClick={() => switchView('login')} className="font-medium text-brand hover:text-opacity-80">
            Sign in
          </button>
        </p>
      </div>
    </>
  );

  const renderForgotView = () => (
    <>
      <div className="text-center">
        <h2 className="mt-6 text-3xl font-extrabold text-text-primary">
          Reset Password
        </h2>
        <p className="mt-2 text-sm text-text-secondary">
          Enter your email to receive a reset link.
        </p>
      </div>
      <form className="mt-8 space-y-6" onSubmit={handleForgotPassword}>
        <div className="rounded-md shadow-sm">
          <input name="email" type="email" autoComplete="email" required className="appearance-none relative block w-full px-3 py-2 border border-accent bg-primary placeholder-text-secondary text-text-primary rounded-md focus:outline-none focus:ring-brand focus:border-brand sm:text-sm" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <button type="submit" className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-primary bg-brand hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand focus:ring-offset-primary">
            Send Reset Link
          </button>
        </div>
      </form>
      <div className="text-center">
        <p className="text-sm text-text-secondary">
          Remembered your password?{' '}
          <button type="button" onClick={() => switchView('login')} className="font-medium text-brand hover:text-opacity-80">
            Sign in
          </button>
        </p>
      </div>
    </>
  );

  const renderContent = () => {
    switch(view) {
        case 'signup': return renderSignUpView();
        case 'forgot': return renderForgotView();
        case 'login':
        default:
            return renderLoginView();
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-primary">
      <div className="w-full max-w-md p-8 space-y-6 bg-secondary rounded-lg shadow-lg">
        {error && <p className="text-sm text-red-400 text-center bg-red-900/50 p-3 rounded-md">{error}</p>}
        {renderContent()}
      </div>
    </div>
  );
};

export default Login;