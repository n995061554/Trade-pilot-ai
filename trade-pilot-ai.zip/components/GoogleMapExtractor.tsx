import React, { useState, useEffect } from 'react';
// FIX: Import Page type
import { MapLead, Page } from '../types';
import { generateMapResponse } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { translations } from '../translations';
import { GenerateContentResponse } from '@google/genai';
// FIX: Import BackArrowIcon
import { BackArrowIcon } from './icons';

interface GoogleMapExtractorProps {
    t: (key: keyof typeof translations.en) => string;
    // FIX: Add setActivePage to props
    setActivePage: (page: Page) => void;
}

const StarRating = ({ rating }: { rating: number }) => {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5; 
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    return (
        <div className="flex items-center">
            <span className="text-yellow-400">{'★'.repeat(fullStars)}</span>
            {halfStar && <span className="text-yellow-400">★</span>}
            <span className="text-gray-500">{'★'.repeat(emptyStars)}</span>
            <span className="ml-2 text-xs text-text-secondary">({rating.toFixed(1)})</span>
        </div>
    );
};

const GoogleMapExtractor: React.FC<GoogleMapExtractorProps> = ({ t, setActivePage }) => {
    const [query, setQuery] = useState('Spice Importers');
    const [location, setLocation] = useState('Dubai');
    const [leads, setLeads] = useState<MapLead[]>([]);
    const [response, setResponse] = useState<GenerateContentResponse | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [userLocation, setUserLocation] = useState<{ latitude: number, longitude: number } | null>(null);

    useEffect(() => {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                setUserLocation({
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                });
            },
            (err) => {
                console.warn("Geolocation permission denied. Searches may be less accurate.", err);
                 // Fallback location (e.g., center of India)
                setUserLocation({ latitude: 20.5937, longitude: 78.9629 });
            }
        );
    }, []);

    const findLeads = async () => {
        if (!userLocation) {
            setError("User location is not available. Please grant permission and try again.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setLeads([]);
        setResponse(null);

        const prompt = `
        Find business listings for "${query}" in or near "${location}". Also provide a brief, plausible 1-2 sentence summary of each company's history and financial status. The output should be a markdown formatted list.
        `;

        try {
            const result = await generateMapResponse(prompt, userLocation);
            setResponse(result);
            // This is a simplified display. A more robust solution would parse the markdown.
            // For now, we simulate JSON extraction for consistency with other tools.
            const simulatedLeads = result.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => ({
                companyName: chunk.maps?.title || 'Unknown Company',
                address: chunk.maps?.placeAnswerSources?.[0]?.address || 'Address not found',
                phone: chunk.maps?.placeAnswerSources?.[0]?.phoneNumber || 'N/A',
                website: 'N/A',
                email: 'N/A',
                rating: chunk.maps?.placeAnswerSources?.[0]?.rating || 4.0,
                establishmentYear: 2010, // Placeholder
                companyHistory: 'A leading importer in the region.', // Placeholder
                financialSummary: 'Stable financial performance with consistent growth.' // Placeholder
            })) || [];
            
             // For demonstration, we'll use a simple regex to pull out the main text and display it.
             // In a real app, you'd use a markdown parser.
            const textResponse = result.text || '';
             // We can't reliably parse the text into the detailed JSON we had before with this model.
             // We'll show the raw markdown and the grounding chunks.
            
        } catch (e) {
            console.error("Failed to get map response:", e);
            setError("The AI returned an invalid response. Please try adjusting your query or try again.");
            setLeads([]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <header className="mb-6">
                {/* FIX: Add back button for consistent UX */}
                <button onClick={() => setActivePage('dashboard')} className="flex items-center gap-2 text-sm text-text-secondary hover:text-brand mb-4 transition-colors">
                  <BackArrowIcon />
                  <span>Back to Dashboard</span>
                </button>
                <h1 className="text-3xl font-bold text-text-primary">{t('mapExtractor')}</h1>
                <p className="text-md text-text-secondary">{t('mapExtractorSubheading')}</p>
            </header>

            <div className="bg-primary p-6 rounded-lg shadow-lg mb-6">
                <form onSubmit={(e) => { e.preventDefault(); findLeads(); }} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div>
                        <label htmlFor="query" className="block text-sm font-medium text-text-secondary">{t('searchQuery')}</label>
                        <input
                            id="query"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm"
                            placeholder="e.g., Rice Wholesalers"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="location" className="block text-sm font-medium text-text-secondary">{t('location')}</label>
                        <input
                            id="location"
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                            className="mt-1 block w-full bg-accent border-highlight rounded-md shadow-sm py-2 px-3 text-text-primary focus:outline-none focus:ring-brand focus:border-brand sm:text-sm"
                            placeholder="e.g., New York"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading || !userLocation}
                        className="w-full bg-brand text-primary font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition disabled:bg-gray-500 h-10"
                    >
                        {isLoading ? <LoadingSpinner /> : t('search')}
                    </button>
                </form>
            </div>

            {isLoading && <div className="text-center py-10"><LoadingSpinner /></div>}
            {error && <div className="bg-red-900/50 text-red-300 p-4 rounded-lg text-center">{error}</div>}

            {!isLoading && response && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-primary p-6 rounded-lg shadow-lg">
                        <h2 className="text-xl font-semibold text-text-primary mb-4">AI Generated Summary</h2>
                        <div className="prose prose-invert max-w-none text-text-secondary whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: response.text?.replace(/\n/g, '<br />') || 'No summary available.' }} />
                    </div>
                     <div className="bg-primary p-6 rounded-lg shadow-lg">
                         <h2 className="text-xl font-semibold text-text-primary mb-4">Data Sources from Google Maps</h2>
                         <div className="space-y-3">
                            {response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk, index) => (
                                <div key={index} className="bg-secondary p-3 rounded-md">
                                    <a 
                                        href={chunk.maps?.uri}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="font-semibold text-brand hover:underline"
                                    >
                                        {index + 1}. {chunk.maps?.title}
                                    </a>
                                    {chunk.maps?.placeAnswerSources?.[0]?.address && <p className="text-sm text-text-secondary mt-1">{chunk.maps.placeAnswerSources[0].address}</p>}
                                </div>
                            ))}
                         </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default GoogleMapExtractor;
